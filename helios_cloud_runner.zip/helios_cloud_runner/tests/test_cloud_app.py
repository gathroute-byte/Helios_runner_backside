import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("HELIOS_API_TOKEN", "test-token-for-unit-tests")

from fastapi.testclient import TestClient
import cloud_app

client = TestClient(cloud_app.app)


def test_health_does_not_claim_scientific_validity():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ready"
    assert "No evidence of model validity" in body["scientific_status"]


def test_backtest_requires_bearer_token():
    response = client.post("/run", files={"panel": ("panel.csv", b"a\n1\n"), "daily": ("daily.csv", b"a\n1\n")})
    assert response.status_code == 401


def test_panel_builder_requires_bearer_token():
    response = client.post("/build-panel", files={"seasons": ("seasons.csv", b"a\n1\n"), "daily": ("daily.csv", b"a\n1\n")})
    assert response.status_code == 401
