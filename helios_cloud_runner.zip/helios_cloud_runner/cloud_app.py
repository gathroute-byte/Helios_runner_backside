from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

APP_DIR = Path(__file__).resolve().parent
SCRIPT = APP_DIR / "helios_backtest.py"
TOKEN = os.environ.get("HELIOS_API_TOKEN", "")
MAX_FILE_BYTES = 25 * 1024 * 1024
app = FastAPI(title="DIAMA HelioS Back-test Runner", version="helios-v0.9-int-flower-fill")


def require_auth(authorization: Optional[str]) -> None:
    if not TOKEN or authorization != f"Bearer {TOKEN}":
        raise HTTPException(status_code=401, detail="A valid Bearer token is required.")


async def save_upload(upload: UploadFile, path: Path) -> None:
    data = await upload.read(MAX_FILE_BYTES + 1)
    if not data:
        raise HTTPException(status_code=400, detail=f"Empty upload: {upload.filename or path.name}")
    if len(data) > MAX_FILE_BYTES:
        raise HTTPException(status_code=413, detail=f"File exceeds the {MAX_FILE_BYTES // (1024 * 1024)} MB limit.")
    path.write_bytes(data)


def run_command(cmd: list[str], timeout: int = 900) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=str(APP_DIR), capture_output=True, text=True, timeout=timeout, check=False)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ready",
        "service": "DIAMA HelioS Back-test Runner",
        "model_version": "helios-v0.9-int-flower-fill",
        "purpose": "Execute the versioned back-test on user-supplied, source-documented data.",
        "scientific_status": "No evidence of model validity is implied by service availability.",
        "authenticated_endpoints": ["POST /build-panel", "POST /run"],
    }


@app.post("/build-panel")
async def build_panel(
    seasons: UploadFile = File(...),
    daily: UploadFile = File(...),
    allow_overlapping_phases: bool = Form(False),
    authorization: Optional[str] = Header(None),
):
    require_auth(authorization)
    work = Path(tempfile.mkdtemp(prefix="helios-build-"))
    try:
        seasons_path, daily_path = work / "seasons.csv", work / "district_daily.csv"
        await save_upload(seasons, seasons_path)
        await save_upload(daily, daily_path)
        out_stem = work / "phase_features"
        cmd = [sys.executable, str(SCRIPT), "build-panel", "--seasons", str(seasons_path),
               "--daily", str(daily_path), "--out", str(out_stem)]
        if allow_overlapping_phases:
            cmd.append("--allow-overlapping-phases")
        result = run_command(cmd)
        if result.returncode != 0 or not (work / "phase_features.csv").exists():
            raise HTTPException(status_code=422, detail={"error": "Panel construction failed; check the input schema and phase dates.",
                                                         "stdout": result.stdout[-5000:], "stderr": result.stderr[-10000:]})
        return FileResponse(str(work / "phase_features.csv"), media_type="text/csv",
                            filename="helios_phase_features.csv",
                            background=BackgroundTask(shutil.rmtree, str(work), ignore_errors=True))
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise


@app.post("/run")
async def run_backtest(
    panel: UploadFile = File(...),
    daily: UploadFile = File(...),
    target: Optional[str] = Form(None),
    interaction_mode: str = Form("auto"),
    run_district_holdout: bool = Form(False),
    allow_overlapping_phases: bool = Form(False),
    source_manifest: Optional[str] = Form(None),
    authorization: Optional[str] = Header(None),
):
    require_auth(authorization)
    if interaction_mode not in {"auto", "vpd", "soil_moisture"}:
        raise HTTPException(status_code=400, detail="interaction_mode must be auto, vpd, or soil_moisture.")
    work = Path(tempfile.mkdtemp(prefix="helios-run-"))
    try:
        panel_path, daily_path = work / "panel.csv", work / "district_daily.csv"
        await save_upload(panel, panel_path)
        await save_upload(daily, daily_path)
        outdir = work / "outputs"
        cmd = [sys.executable, str(SCRIPT), "run", "--panel", str(panel_path), "--daily", str(daily_path),
               "--out", str(outdir), "--interaction-mode", interaction_mode]
        if target:
            cmd += ["--target", target]
        if allow_overlapping_phases:
            cmd.append("--allow-overlapping-phases")
        if run_district_holdout:
            cmd.append("--run-district-holdout")
        if source_manifest:
            import json
            try:
                manifest_obj = json.loads(source_manifest)
            except json.JSONDecodeError as exc:
                raise HTTPException(status_code=400, detail=f"source_manifest must be valid JSON: {exc.msg}")
            manifest_path = work / "source_manifest.json"
            manifest_path.write_text(json.dumps(manifest_obj, indent=2), encoding="utf-8")
            cmd += ["--source-manifest", str(manifest_path)]
        result = run_command(cmd)
        if result.returncode != 0 or not (outdir / "report.md").exists():
            raise HTTPException(status_code=422, detail={"error": "Back-test failed; no scientific result returned.",
                                                         "stdout": result.stdout[-5000:], "stderr": result.stderr[-10000:]})
        zip_path = work / "helios_backtest_results.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for item in outdir.rglob("*"):
                if item.is_file():
                    zf.write(item, item.relative_to(outdir))
            zf.writestr("execution_log.txt", result.stdout + "\n--- STDERR ---\n" + result.stderr)
        return FileResponse(str(zip_path), media_type="application/zip", filename="helios_backtest_results.zip",
                            background=BackgroundTask(shutil.rmtree, str(work), ignore_errors=True))
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise
